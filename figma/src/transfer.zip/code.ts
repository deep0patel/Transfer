import { convertToCode } from "bricks-core/src";

figma.showUI(__html__, { height: 600, width: 350 });

figma.ui.onmessage = async (msg) => {
  if (msg.type === "styled-bricks-nodes") {
    const promise = convertToCode(figma.currentPage.selection, {
      language: msg.options.language,
      cssFramework: msg.options.cssFramework,
      uiFramework: msg.options.uiFramework,
    });

    await handleConversionPromise(promise);
  }

  if (msg.type === "convert-entire-wireframe") {
    const pages = figma.root.children.filter(node => node.type === "PAGE");

    for (const page of pages) {
      figma.currentPage = page; // Temporarily switch to the page

      const promise = convertToCode(page.children, {
        language: msg.options.language,
        cssFramework: msg.options.cssFramework,
        uiFramework: msg.options.uiFramework,
      });

      try {
        await handleConversionPromise(promise, page.name);
        // displayNodesMetadata(figma.currentPage.children);

        
      } catch (error) {
        console.error(`Error converting page ${page.name}:`, error);
        figma.ui.postMessage({
          type: "conversion-error",
          pageName: page.name,
          error: true,
          message: `Error converting page ${page.name}: ${error.message}`,
        });
      }
    }

    figma.ui.postMessage({ type: "conversion-complete" });
  }

  if (msg.type === "display-selected-metadata") {
    displayNodesMetadata(figma.currentPage.selection);
  }

  if (msg.type === "display-entire-page-metadata") {
    displayNodesMetadata(figma.currentPage.children);
  }

  if (msg.type === "update-settings") {
    await figma.clientStorage.setAsync("settings", msg.settings);

    let settings = await figma.clientStorage.getAsync("settings");

    figma.ui.postMessage({
      type: "settings",
      settings,
    });
  }

  if (msg.type === "update-connection-status") {
    figma.clientStorage.setAsync("connection-status", msg.connected);
  }

  if (msg.type === "adjust-plugin-screen-size") {
    figma.ui.resize(msg.width, msg.height);
  }

  if (msg.type === "get-settings") {
    let settings = await figma.clientStorage.getAsync("settings");

    figma.ui.postMessage({
      type: "settings",
      settings,
    });
  }
};

figma.on("selectionchange", async () => {
  figma.ui.postMessage({
    type: "selection-change",
    isComponentSelected: figma.currentPage.selection.length > 0,
    selectedComponents: figma.currentPage.selection.map((x) => x.name),
  });
});

// Helper function to handle conversion promise and send messages to UI
const handleConversionPromise = async (promise: Promise<any>, pageName?: string) => {
  try {
    const files = await promise;
    figma.ui.postMessage({
      type: "generated-files",
      files,
      pageName: pageName || "Current Page",
    });
  } catch (e) {
    const errorDetails = {
      error: e.name,
      message: e.message,
      stack: e.stack,
    };

    console.error(`Error from Figma core on ${pageName || "current page"}:`, errorDetails);

    figma.ui.postMessage({
      type: "generated-files",
      files: [],
      error: true,
      pageName: pageName || "Current Page",
      message: `Error on ${pageName || "current page"}: ${e.message}`
    });

    throw e; // Rethrow the error for page iteration handling
  }
};

// Recursive function to get metadata of a node and all its descendants
const getNodeMetadata = (node: SceneNode): any => {
  const nodeData = {
    id: node.id,
    name: node.name,
    type: node.type,
    width: node.width,
    height: node.height,
    x: node.x,
    y: node.y,
    children: [],
    // Add other properties if needed
  };

  // If the node has children, recursively get their metadata
  if ("children" in node && node.children.length > 0) {
    nodeData.children = node.children.map(child => getNodeMetadata(child));
  }

  return nodeData;
};

// Function to get metadata for all nodes and send to the UI
const displayNodesMetadata = (nodes: readonly SceneNode[]) => {
  const nodesData = nodes.map(node => getNodeMetadata(node));

  // Post the JSON metadata to the UI
  figma.ui.postMessage({
    type: "display-nodes-metadata",
    data: JSON.stringify(nodesData, null, 2) // Pretty-print JSON
  });
};





